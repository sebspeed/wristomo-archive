# Original source links — WRISTOMO

These are source URLs, not copied originals.

- **OFF-001** [Product announcement (English)](https://www.docomo.ne.jp/english/info/media_center/pr/2003/000942.html) — NTT DoCoMo (2003-03-26), verified
- **OFF-002** [Launch and sales announcement (English)](https://www.docomo.ne.jp/english/info/media_center/pr/2003/000956.html) — NTT DoCoMo (2003-05-01), verified
- **OFF-003** [Launch announcement (Japanese)](https://www.docomo.ne.jp/info/news_release/page/20030501.html) — NTT DoCoMo (2003-05-01), verified
- **OFF-004** [Notice: DoCoMo PHS service closure](https://www.docomo.ne.jp/info/notice/page/070806_00.html) — NTT DoCoMo (2007-08-06), verified
- **OFF-005** [Historical 2003 annual filing mentioning WRISTOMO](https://www.docomo.ne.jp/english/corporate/ir/binary/pdf/library/sec/backnumber/fy2003_e.pdf) — NTT DoCoMo (2004), verified
- **OFF-006** [Manual downloads index (no WRISTOMO manual confirmed)](https://www.docomo.ne.jp/support/manual/) — NTT DoCoMo (current), verified-index-only
- **OFF-007** [History of Innovation (English)](https://www.sii.co.jp/en/tech/002) — Seiko Instruments (current), verified
- **OFF-008** [History of Innovation (Japanese)](https://www.sii.co.jp/tech/002) — Seiko Instruments (current), verified
- **OFF-009** [Compact NetFront on WRISTOMO](https://www.access-company.com/news_event/archives/20030407/) — ACCESS Co. (2003-04-07), verified
- **REG-001** [JATE 2003 certified terminals list](https://www.jate.or.jp/jp/tanmatsu/old/2003.html) — JATE (2003-02-05), verified
