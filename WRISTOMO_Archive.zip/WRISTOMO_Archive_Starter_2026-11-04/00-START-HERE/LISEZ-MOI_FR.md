# WRISTOMO — Dossier d'archives, 4 novembre 2026

## Contenu réel de l'archive

- 24 sources documentaires identifiées, indexées et liées (sources officielles, homologation, brevets et presse historique).
- Raccourcis `.url` ouvrables sur Windows pour accéder aux pages originales.
- Un **dossier technique de synthèse original en PDF** rédigé pour l'archive, avec citations d'URL.
- Quatre publications PDF de brevets Seiko *accessibles par liens*; la correspondance précise de leurs schémas avec les pièces de la WRISTOMO **n'est pas établie**.
- Un script PowerShell pour **télécharger les PDF publics sur votre propre PC**. Ces PDF ne sont PAS inclus dans ce ZIP.
- Des espaces de classement pour les manuels, le chargeur, les modèles STL et la documentation de réparation.

## Limite importante

**Aucun manuel d'utilisation officiel WRISTOMO intégral ni manuel du chargeur n'a été retrouvé sous forme de PDF librement téléchargeable et vérifiable pendant cette recherche.** Ne pas présenter les brevets comme un manuel de maintenance.

Les textes et photos des pages NTT DoCoMo, Seiko, ACCESS et de la presse restent la propriété de leurs éditeurs. Le ZIP contient leurs liens et des synthèses inédites, pas des copies intégrales de ces pages. Ne pas publier de documents propriétaires sur GitHub sans autorisation ou licence adéquate.

## Priorités

1. **00-START-HERE/SOURCES.csv** : inventaire maître (compatible Excel et GitHub).
2. **10-Original-Research-Dossier/WRISTOMO_Technical_Reference_2026.pdf** : fiche structurée et vérifiée.
3. **01-Official-NTT-DoCoMo** : source primaire (annonce mars, lancement mai, caractéristiques, fin réseau PHS).
4. **04-Patents-PDF-links** : brevets publiés avec dessins à vérifier sur matériel réel.
5. **09-Tools/download_official_pdfs.ps1** : téléchargements locaux pour étude privée.
6. **05-Manuals-and-Software** : inventaire des éléments non retrouvés.
7. **06-Charger-Research** : démarche de sécurité et identification.
8. **07-Repairs-STL-and-CAD** : emplacement pour vos fichiers STL / STEP personnels.

## Correction technique

`A03-0015JP` est le **numéro de certification JATE** attribué à WRISTOMO (Seiko Instruments, 5 février 2003). Il ne constitue pas, à lui seul, une référence commerciale prouvée.

## Statut

Recherche documentaire réalisée le 2026-11-04. Sources historiques, liens susceptibles d'évoluer. Aucune tension, polarité ni affectation des contacts du chargeur d'origine n'a pu être authentifiée.
