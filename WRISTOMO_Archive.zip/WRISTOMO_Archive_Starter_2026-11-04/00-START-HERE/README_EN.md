# WRISTOMO: Community Technical Preservation Archive

Independent, unofficial preservation resource for the NTT DoCoMo WRISTOMO wearable PHS handset (2003), manufactured by Seiko Instruments.

## Contents

- `00-START-HERE/SOURCES.csv`: 24 sourced entries, identifiers, languages, dates, verified URLs, and copyright notes.
- `01-Official-NTT-DoCoMo/`: launch documentation and PHS shutdown **source links**.
- `02-Official-Seiko-and-ACCESS/`: manufacturer and technology supplier links.
- `03-Regulatory-JATE/`: certification record and identity clarification.
- `04-Patents-PDF-links/`: four published Seiko patent PDF references **not confirmed to represent exact WRISTOMO parts**.
- `05-Manuals-and-Software/`: missing manuals / discontinued synchronization program tracking.
- `06-Charger-Research/`: charger investigation and safety checklist.
- `07-Repairs-STL-and-CAD/`: add original CAD/STL/photos with an appropriate licence.
- `08-Historical-Press-Links/`: contemporary external reporting.
- `09-Tools/`: optional Windows PowerShell downloader for personal research PDFs.
- `10-Original-Research-Dossier/`: original technical reference PDF authored for this collection.

## Copyright

No copyrighted NTT DoCoMo manuals or publisher-hosted photographs are bundled. URLs point to original sources. Patent PDF URLs are provided for independent review; confirm reuse rights before publishing any downloaded binary to GitHub.

## Not yet located

A verifiable, freely accessible **original WRISTOMO user manual PDF**, full charger datasheet and manufacturer-approved charger pinout were not located in this search.

## Identification caveat

`A03-0015JP` is the Japanese JATE certification number (2003-02-05), not a verified commercial model number.

Research date: 2026-11-04.
