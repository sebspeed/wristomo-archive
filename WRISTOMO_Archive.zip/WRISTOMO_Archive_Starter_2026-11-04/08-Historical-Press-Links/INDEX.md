# 08 Historical Press Links

Verified source links; third-party originals are **not** embedded. Open the `.url` shortcuts on Windows.

- **HIS-001** — [NTT DoCoMo wristwatch PHS development](https://internet.watch.impress.co.jp/www/article/2003/0326/wristomo.htm) (Internet Watch / Impress, 2003-03-26; HTML). Contemporary development reporting **Status:** verified.
- **HIS-002** — [WRISTOMO commercial launch](https://internet.watch.impress.co.jp/www/article/2003/0501/wristomo.htm) (Internet Watch / Impress, 2003-05-01; HTML). Contemporary launch; 5,000 units reported **Status:** verified.
- **HIS-003** — [Photo review of WRISTOMO](https://www.itmedia.co.jp/mobile/0304/08/n_wristomo.html) (ITmedia Mobile, 2003-04-08; HTML). Photos and functionality, useful for external reference **Status:** verified.
- **HIS-004** — [WRISTOMO usage analysis, part 2](https://www.itmedia.co.jp/mobile/0304/10/n_wrist_2.html) (ITmedia Mobile, 2003-04-10; HTML). Contemporary user interface and browser observations **Status:** verified.
- **HIS-005** — [ASCII.jp design news](https://ascii.jp/elem/000/000/336/336946/) (ASCII.jp, 2003-03-26; HTML). Appearance and early specifications **Status:** verified.
- **HIS-006** — [DoCoMo and Seiko unveil Wristomo](https://wirelesswatch.jp/2003/05/02/docomo-and-seiko-unveil-wristomo/) (Wireless Watch Japan, 2003-05-02; HTML). Wrist Mount System contemporary description **Status:** verified.
- **HIS-007** — [2003 WRISTOMO release retrospective](https://k-tai.watch.impress.co.jp/docs/news/1250715.html) (Keitai Watch / Impress, 2020-05-07; HTML). Illustrations and release-date retrospective **Status:** verified.
- **HIS-008** — [DoCoMo wristwatch PHS with photos](https://www.itmedia.co.jp/mobile/0303/26/n_dwristo.html) (ITmedia Mobile, 2003-03-26; HTML). Mechanism description and original interview **Status:** verified.
