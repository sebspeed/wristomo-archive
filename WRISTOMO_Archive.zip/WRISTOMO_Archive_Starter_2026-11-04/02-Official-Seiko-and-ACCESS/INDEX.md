# 02 Official Seiko and ACCESS

Verified source links; third-party originals are **not** embedded. Open the `.url` shortcuts on Windows.

- **OFF-007** — [History of Innovation (English)](https://www.sii.co.jp/en/tech/002) (Seiko Instruments, current; HTML). Manufacturer confirms 2003 WRISTOMO release **Status:** verified.
- **OFF-008** — [History of Innovation (Japanese)](https://www.sii.co.jp/tech/002) (Seiko Instruments, current; HTML). Original manufacturer chronology **Status:** verified.
- **OFF-009** — [Compact NetFront on WRISTOMO](https://www.access-company.com/news_event/archives/20030407/) (ACCESS Co., 2003-04-07; HTML). Confirms embedded web browser and Seiko licence path **Status:** verified.
