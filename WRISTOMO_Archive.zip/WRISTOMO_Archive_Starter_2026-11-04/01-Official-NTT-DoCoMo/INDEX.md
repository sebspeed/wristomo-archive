# 01 Official NTT DoCoMo

Verified source links; third-party originals are **not** embedded. Open the `.url` shortcuts on Windows.

- **OFF-001** — [Product announcement (English)](https://www.docomo.ne.jp/english/info/media_center/pr/2003/000942.html) (NTT DoCoMo, 2003-03-26; HTML). Launch development announcement and specifications **Status:** verified.
- **OFF-002** — [Launch and sales announcement (English)](https://www.docomo.ne.jp/english/info/media_center/pr/2003/000956.html) (NTT DoCoMo, 2003-05-01; HTML). Standard kit, optional SI1001 cable, sale date and MSRP **Status:** verified.
- **OFF-003** — [Launch announcement (Japanese)](https://www.docomo.ne.jp/info/news_release/page/20030501.html) (NTT DoCoMo, 2003-05-01; HTML). Japanese original feature list and technical specifications **Status:** verified.
- **OFF-004** — [Notice: DoCoMo PHS service closure](https://www.docomo.ne.jp/info/notice/page/070806_00.html) (NTT DoCoMo, 2007-08-06; HTML). PHS ended 2008-01-07, WRISTOMO schedule software download also removed **Status:** verified.
- **OFF-005** — [Historical 2003 annual filing mentioning WRISTOMO](https://www.docomo.ne.jp/english/corporate/ir/binary/pdf/library/sec/backnumber/fy2003_e.pdf) (NTT DoCoMo, 2004; PDF). Corporate historical mention of WRISTOMO **Status:** verified.
- **OFF-006** — [Manual downloads index (no WRISTOMO manual confirmed)](https://www.docomo.ne.jp/support/manual/) (NTT DoCoMo, current; HTML). Search landing page; WRISTOMO PDF not located **Status:** verified-index-only.
