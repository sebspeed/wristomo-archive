# Manuals and software — status, 2026-11-04

- Original WRISTOMO user manual (Japanese): **NOT LOCATED as a verified freely available PDF**.
- Printed user manual: period second-hand listings show it exists, but no usable rights-cleared scan was located.
- Charger instructions or service manual: **NOT LOCATED**.
- SI1001 synchronization cable manual: **NOT LOCATED**.
- WRISTOMO schedule-management software: NTT DoCoMo explicitly stated it would stop providing the download on **2008-01-07** (OFF-004).

Verification steps: consult NTT DoCoMo historical support; contact Seiko Instruments regarding archival materials; ask r/Wristomo collectors who own the original packaging to scan documents **with appropriate permission**; log precise filenames, provenance and rights of each new item.

Useful sources:
- https://www.docomo.ne.jp/support/manual/
- https://www.docomo.ne.jp/info/notice/page/070806_00.html
