# Téléchargement local des PDF (Windows)

Ouvrez PowerShell dans le dossier `09-Tools` et exécutez :

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\download_official_pdfs.ps1
```

Le script récupère les **quatre PDF publics de brevets américains** et **un rapport annuel NTT DoCoMo** dans le sous-dossier `private-source-pdfs`, après validation de l'en-tête PDF.

Il **n'existe pas de PDF de manuel WRISTOMO dans ce lot**. Si la source refuse le téléchargement, le script affiche `FAILED`. Le script n'a pas été exécuté ici (accès externe direct indisponible depuis l'environnement de génération).

Ne téléversez pas ces fichiers sur un GitHub public avant vérification des droits applicables. Préférez publier les fichiers originaux de votre projet et les liens vers les sources tierces.
