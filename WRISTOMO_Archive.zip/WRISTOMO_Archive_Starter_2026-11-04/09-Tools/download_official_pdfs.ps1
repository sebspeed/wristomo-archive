﻿# Collect externally hosted PDF sources for private technical research.
# This script does not run automatically; use it on a Windows computer with Internet.
# Respect source licensing; do not commit these downloaded files to public GitHub without rights checks.
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$dest = Join-Path $PSScriptRoot "private-source-pdfs"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$files = @(
    @{ name = "PAT-001_US20010036264A1.pdf"; url = "https://patentimages.storage.googleapis.com/48/19/b2/008137502b0ce9/US20010036264A1.pdf" },
    @{ name = "PAT-002_US20020167866A1.pdf"; url = "https://patentimages.storage.googleapis.com/c4/62/b0/c5b66d9abb678c/US20020167866A1.pdf" },
    @{ name = "PAT-003_US20030035347A1.pdf"; url = "https://patentimages.storage.googleapis.com/13/52/af/c38e2aaf54c488/US20030035347A1.pdf" },
    @{ name = "PAT-004_US6905240.pdf"; url = "https://patentimages.storage.googleapis.com/5b/a6/8e/a7cbf7fd818c21/US6905240.pdf" },
    @{ name = "OFF-005_NTTDocomo_2003_Annual_Report.pdf"; url = "https://www.docomo.ne.jp/english/corporate/ir/binary/pdf/library/sec/backnumber/fy2003_e.pdf" }
)
foreach ($f in $files) {
  $target = Join-Path $dest $f.name
  try {
    Invoke-WebRequest -Uri $f.url -OutFile $target -UseBasicParsing -TimeoutSec 90
    $bytes = [System.IO.File]::ReadAllBytes($target)
    if ($bytes.Length -lt 5 -or [System.Text.Encoding]::ASCII.GetString($bytes, 0, 4) -ne "%PDF") { throw "Downloaded file is not a valid PDF." }
    Write-Host ("OK: " + $f.name + " / " + $bytes.Length + " bytes")
  } catch {
    Remove-Item $target -ErrorAction SilentlyContinue
    Write-Warning ("FAILED: " + $f.name + " - " + $_.Exception.Message)
  }
}
Write-Host "PDFs downloaded into $dest"
