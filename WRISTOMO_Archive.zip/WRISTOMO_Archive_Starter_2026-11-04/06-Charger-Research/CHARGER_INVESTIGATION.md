# WRISTOMO charger reconstruction: source-based research plan

**Confirmed:** the original retail kit included a battery charger (OFF-002). It has not been verified that the charging interface shares signals or electrical characteristics with the SI1001 PC synchronization cable.

**Unconfirmed / do not guess:** original adapter output voltage, current limit, polarity, socket pin assignment, charge termination electronics, charging protocol and safe battery state.

Before powering any original device:
1. Obtain photos of every face of an original charger and its printed electrical label, connector dimensions and polarity marking.
2. Obtain high-resolution closeups of the watch charging contacts and note whether data and power interfaces are separate.
3. Locate manufacturer's user instructions and battery chemistry/model identification.
4. Assess cell condition, especially swelling or excessive self-discharge of aged lithium-polymer cells. Do not attempt direct charging of unknown, degraded cells.
5. Have electrical properties independently measured by a qualified electronics technician **before** designing replacement hardware.
6. Record every measured value with equipment model, uncertainty, photographs and source attribution. Never publish speculative pinouts as verified.

Supporting evidence:
- OFF-002 (retail kit charger supplied): https://www.docomo.ne.jp/english/info/media_center/pr/2003/000956.html
- HIST-002 is external historical reporting for the older battery chemistry mention, not the primary official battery data.
