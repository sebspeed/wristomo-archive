# 03 Regulatory JATE

Verified source links; third-party originals are **not** embedded. Open the `.url` shortcuts on Windows.

- **REG-001** — [JATE 2003 certified terminals list](https://www.jate.or.jp/jp/tanmatsu/old/2003.html) (JATE, 2003-02-05; HTML). A03-0015JP is certification number for WRISTOMO, Seiko applicant **Status:** verified.
