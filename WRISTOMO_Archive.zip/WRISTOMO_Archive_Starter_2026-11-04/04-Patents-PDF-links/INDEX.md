# 04 Patents PDF links

Verified source links; third-party originals are **not** embedded. Open the `.url` shortcuts on Windows.

- **PAT-001** — [Wristwatch type wireless telephone, US20010036264A1](https://patentimages.storage.googleapis.com/48/19/b2/008137502b0ce9/US20010036264A1.pdf) (US patent publication / Seiko inventors, 2001-11-01; PDF). Potentially useful drawings of wristwatch-style PHS architecture **Status:** verified-pdf-relatedness-unconfirmed.
- **PAT-002** — [Wrist-portable equipment, US20020167866A1](https://patentimages.storage.googleapis.com/c4/62/b0/c5b66d9abb678c/US20020167866A1.pdf) (US patent publication / Seiko inventors, 2002-11-14; PDF). Mechanical detail / wrist equipment; no direct WRISTOMO attribution **Status:** verified-pdf-relatedness-unconfirmed.
- **PAT-003** — [Case, strap and timepiece, US20030035347A1](https://patentimages.storage.googleapis.com/13/52/af/c38e2aaf54c488/US20030035347A1.pdf) (US patent publication / Seiko inventors, 2003-02-20; PDF). Strap engagement / anti-rotation mechanism **Status:** verified-pdf-relatedness-unconfirmed.
- **PAT-004** — [Case, strap and timepiece, US6905240B2](https://patentimages.storage.googleapis.com/5b/a6/8e/a7cbf7fd818c21/US6905240.pdf) (US patent / Seiko Instruments, 2005-06-14; PDF). Granted version of PAT-003, diagrams and material example **Status:** verified-pdf-relatedness-unconfirmed.
- **PAT-005** — [Patent metadata: US20010036264A1](https://patents.google.com/patent/US20010036264A1/en) (Google Patents, 2001-11-01; HTML). Searchable metadata and patent family **Status:** verified.
- **PAT-006** — [Patent metadata: US20030035347A1](https://patents.google.com/patent/US20030035347A1/en) (Google Patents, 2003-02-20; HTML). Searchable claims and materials **Status:** verified.
