# 3D parts and rubber pad restoration

The WRISTOMO's small rubber-like component at the underside/end attachment is a priority restoration target. No **verified manufacturer dimensioned drawing** was located.

Use the following community workflow:

1. Photograph the original part from six orthogonal directions next to a scale.
2. Record caliper measurements with units, tolerances and uncertainty.
3. Keep a versioned editable CAD source (`.STEP` or `.FCStd`) and exported `.STL` versions.
4. Label early designs `PROTOTYPE — UNVALIDATED`; verify clipping force, fatigue and clearance on sacrificial parts before installing on a valuable original unit.
5. For casting or 3D printing, test candidate elastomers and record actual Shore hardness, shrinkage and long-term behavior.
6. Publish only your own models and images (or permissioned contributed works).

**The user's actual STL and photos are not included in this ZIP**, because these files were not available as attached source files for this request.

Candidate Seiko patent references PAT-001 through PAT-004 may inform general research; NONE is confirmed as a WRISTOMO manufacturing blueprint or exact replacement geometry.
